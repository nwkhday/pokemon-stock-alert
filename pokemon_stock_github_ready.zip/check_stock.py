import os,json,hashlib,re,requests
from bs4 import BeautifulSoup

CFG=json.load(open("config.json",encoding="utf-8"))
STATE_FILE="state.json"
def state():
    try:return json.load(open(STATE_FILE))
    except:return {}
def save(s):json.dump(s,open(STATE_FILE,"w"),ensure_ascii=False,indent=2)

def alert(msg):
    token=os.environ.get("TELEGRAM_BOT_TOKEN"); chat=os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat: return
    requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
      json={"chat_id":chat,"text":msg,"disable_web_page_preview":False},timeout=20)

def check(url,domain):
    if not re.match(r"^https?://([^/]*\.)?"+re.escape(domain)+r"(/|$)",url,re.I): return "INVALID"
    r=requests.get(url,headers={"User-Agent":"Mozilla/5.0 (Android 16) AppleWebKit/537.36 Chrome/140 Safari/537.36"},timeout=25)
    text=BeautifulSoup(r.text,"html.parser").get_text(" ",strip=True).lower()
    out=["rupture de stock","indisponible","épuisé","non disponible"]
    inn=["en stock","ajouter au panier","disponible à l'achat","disponible en livraison","click & collect"]
    return "IN_STOCK" if any(x in text for x in inn) and not any(x in text for x in out) else "OUT"

s=state()
for store,d in CFG["stores"].items():
  for url in d["urls"]:
    k=hashlib.sha256((store+"|"+url).encode()).hexdigest()
    try:
      st=check(url,d["domain"])
      print(store,st,url)
      if st=="IN_STOCK" and s.get(k)!="IN_STOCK":
        alert(f"🚨 POKÉMON 30 ANS DISPONIBLE\n\n🏪 {store}\n🔗 {url}")
      s[k]=st
    except Exception as e: print("ERROR",store,e)
save(s)
